<?php include('file/manu.php'); ?>

    <!-- body section start -->
    <div class="body-part">
        <div class="wrapper">
           <b class="dashboard"><h1>Manage Admin</h1></b> 
            <br/>
           <a href="addAdmin.php" target="_blank"> <button class="btn-primary">Add Manager</button></a>
            <table class="tbl-header">
                <tr>
                    <th>S.N</th>
                    <th>Full Name</th>
                    <th>User Name</th>
                    <th>Actions</th>
                </tr>

                <tr>
                    <td>1</td>
                    <td>tanvir Alam</td>
                    <td>Tanvir</td>
                    <td><a href="#"> <button class="btn-secondary">Add Manager</button></a> 
                    <a href="#"> <button class="btn-denger">Add Manager</button></a>
                    </td>
                </tr> 
                <tr>
                    <td>2</td>
                    <td>Shihab</td>
                    <td>Shariar</td>
                    <td><a href="#"> <button class="btn-secondary">Add Manager</button></a> 
                    <a href="#"> <button class="btn-denger">Add Manager</button></a></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>hasan</td>
                    <td>Hasan</td>
                    <td><a href="#"> <button class="btn-secondary">Add Manager</button></a> 
                    <a href="#"> <button class="btn-denger">Add Manager</button></a></td>
                </tr>
        </table>
        </div>
    </div>
    <!-- footer part -->
<?php include('file/footer.php'); ?>
<!-- manu -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Resturent</title>
</head>
<body>
<div class="container">
    <!-- manu start -->
    <div class="manu">
        <div class="wrapper">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="manageAdmin.php">Admin</a></li>
                <li><a href="manageCategori.php">Categori</a></li>
                <li><a href="manageFood.php">Food</a></li>
                <li><a href="manageOrder.php">Order</a></li>
            </ul>
        </div>
    </div>

    <!--footer-->

    <div class="footer">
        <div class="wrapper">
            <p>2022 All rights reserved , some Resturent.Developed By <a href="#">Tanvir</a> , <a href="#">Shihab</a> & <a href="#">Hasan</a></p>
        </div>
    </div>
</div>

</html>