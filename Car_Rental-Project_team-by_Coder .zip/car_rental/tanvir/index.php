<?php include('file/manu.php');?>
    <!-- body section start -->
    <div class="body-part">
        <div class="wrapper">
           <b class="dashboard">
               <h1>DashBoard</h1>
            </b> 
           <div class="col-4 text-center">
                <h1>5</h1>
           </div>
           <div class="col-4 text-center">
                <h1>%</h1>
           </div>
           <div class="col-4 text-center">
                <h1>%</h1>
            </div>
            <div class="col-4 text-center">
                <h1>%</h1>
            </div>
            <!-- <div class="col-4 text-center">
                <h1>%</h1>
            </div> -->
        </div>
        <div class="clearfooter"></div>
    </div>
    <!-- footer part -->
<?php include('file/footer.php'); ?>